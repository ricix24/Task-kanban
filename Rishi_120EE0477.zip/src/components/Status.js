import React from "react";
import notes from "../notes";
import "./Status.css";
import logo from "./logo.png";
import logo1 from "./logo1.jpg";

function Ticket({ ticket }) {
  return (
    <div className="ticket">
      <div className="note">
        <h3 className="heading"><div> {ticket.id}</div>  <div className="profileicons">
            <img className="logo" src={logo}/> 
        </div></h3>
        <p>{ticket.title}</p>
        <h3 className="heading1">
        <div><img className="logo1" src={logo1}/> </div>
        <div> {ticket.tag}</div>  
        </h3>
      </div>
    </div>
  );
}

function Status() {
  const allTickets = notes.flatMap(note => note.tickets);

  const ticketsByStatus = allTickets.reduce((acc, ticket) => {
    if (!acc[ticket.status]) {
      acc[ticket.status] = [];
    }
    acc[ticket.status].push(ticket);
    return acc;
  }, {});

  return (
    <div className="statusContainer">
      <h1 className="prio">Status-wise</h1>
      <div className="status-columns">
        {Object.keys(ticketsByStatus).map(status => (
          <div key={status} className="status-column">
            <h2 className="status-title">{status}</h2>
            <div className="note-list">
              {notes.map(note => (
                <div key={note.id}>
                  <h3>{note.title}</h3>
                  {note.tickets
                    .filter(ticket => ticket.status === status)
                    .map(ticket => (
                      <Ticket key={ticket.id} ticket={ticket} />
                    ))}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Status;