import React from "react";
import notes from "../notes";
import "./Priority.css";
import logo from "./logo.png";
import logo1 from "./logo1.jpg";


function Ticket({ ticket }) {
  return (
    <div className="ticket">
      <div className="note">
        <h3 className="heading"><div> {ticket.id}</div>  <div className="profileicons">
            <img className="logo" src={logo}/> 
        </div></h3>
        <p>{ticket.title}</p>
        <h3 className="heading1">
        <div><img className="logo1" src={logo1}/> </div>
        <div> {ticket.tag}</div>  
        </h3>
      </div>
    </div>
  );
}

console.log(10);

function Priority() {
  const priorityColumns = [];

  for (let priority = 0; priority <= 3; priority++) {
    const ticketsWithPriority = notes[0].tickets.filter(
      ticket => ticket.priority === priority
    );

    if (ticketsWithPriority.length > 0) {
      const column = (
        <div key={priority} className="priority-column">
          <h2 className="priority-title">Priority: {priority}</h2>
          <div className="ticket-list">
            {ticketsWithPriority.map(ticket => (
              <Ticket key={ticket.id} ticket={ticket} />
            ))}
          </div>
        </div>
      );

      priorityColumns.push(column);
    }
  }

  return (
    <div className="container">
      <h1 className="prio">Tickets by Priority</h1>
      <div className="priority-columns">
        {priorityColumns}
      </div>
    </div>
  );
}

export default Priority;