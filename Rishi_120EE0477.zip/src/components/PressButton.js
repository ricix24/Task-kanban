import React, { useState } from "react";
import "./PressButton.css";
import Priority from "./Priority";
import Status from "./Status";
import Users from "./Users";
import Priority1 from "./Priority1";


function PressButton() {
  const [showButtons, setShowButtons] = useState(false);
  const [showGroupingButtons, setShowGroupingButtons] = useState(false);
  const [showOrderingButtons, setShowOrderingButtons] = useState(false);

  const [group, setGroup] = useState('1');
  const [sortGroup, setSortGroup] = useState('4');

  const handleDisplayClick = () => {
    setShowButtons(!showButtons);
    setShowGroupingButtons(false);
    setShowOrderingButtons(false);
  };

  const handleGroupingClick = () => {
    setShowGroupingButtons(!showGroupingButtons);
    setShowOrderingButtons(false);
    // setShowButtons(false); // Close display buttons
    setCh(true);
  };

  const handleOrderingClick = () => {
    setShowOrderingButtons(!showOrderingButtons);
    setShowGroupingButtons(false);
    setCh(false);
    // setShowButtons(false); // Close display buttons
  };

  const setChange = (e) => {
    setGroup(e.target.value);
    setCh(true);
  };

  const setSortChange = (e) => {
    setSortGroup(e.target.value);
    console.log(e.target.value);
    setCh(false);
  };

  const [ch, setCh] = useState(true);
  return (
    <div className="container">
      <div className="navigation">
        <button onClick={handleDisplayClick}> <i class="fa-solid fa-sliders"></i> Display</button>
        {showButtons && (
          <div className="sub-navigation">
            <div className="dropdown-wrapper">
              <button onClick={handleGroupingClick}>Grouping</button>
              {showGroupingButtons && (
                <select value={group} className="dropdown" onChange={setChange}>
                  <option value='1'>Status</option>
                  <option value='2'>Priority</option>
                  <option value='3'>User</option>
                </select>
              )}
            </div>
            <div className="dropdown-wrapper">
              <button onClick={handleOrderingClick}>Ordering</button>
              {showOrderingButtons && (
                //<div className="ordering-submenu">
                  <select value={sortGroup} className="dropdown" onChange={setSortChange}>
                    <option value='4'>Priority</option>
                    <option value='5'>Title</option>
                  </select>
               // </div>
              )}
            </div>
          </div>
        )}
      </div>
      <div onClick={handleDisplayClick}>
      {ch && 
        <div>
        {group === '1' && <Status />}
        {group === '2' && <Priority1 />}
        {group === '3' && <Users />}
      </div>
      }
      {
        !ch &&
        <div>
        {sortGroup === '4' && <Priority />}
        {sortGroup === '5' && <Users />}
      </div>
      }
      </div>
    </div>
  );
}
export default PressButton;
