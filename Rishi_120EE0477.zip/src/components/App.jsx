// import React, { useState } from 'react';
// import Priority from './Priority';
// import ButtonGroup from './ButtonGroup';
// import Display from './Display';
// import Status from './Status';
// import Users from './Users';


// import DropButton from './Navbar'
// import Navbar from './Navbar';

// const buttons = [
//     "display", "priority", "status", "user","title"
// ]


// const RenderComponent = ({index}) => {
//     switch (index) {
//         case 0: return <Display />
//         // break;
//         case 1: return <Priority />
//         // break;
//         case 2: return <Status />
//         // break;
//         case 3: return <Users />
//         // break;

//         default:
//             break;
//     }
// }

// function App() {
//     const [isSelected, setIsSelected] = useState(0)
//   return (
//     <div className='app-container'>
//       <Navbar buttons={buttons} isSelected={isSelected} setIsSelected={setIsSelected}/>
//       <RenderComponent index={isSelected} />
//       {/* <PressButton/> */}
//     </div>
//   );
// }

// export default App;


// import React, { useState } from 'react';
// // import './App.css'; // Import your CSS file
// import Priority from './Priority';
// // import ButtonGroup from './ButtonGroup';
// import Display from './Display';
// import Status from './Status';
// import Users from './Users';
// import Navbar from './Navbar'; // Import your Navbar component

// const buttons = [
//   "Display", "Priority", "Status", "User", "Title"
// ];

// const RenderComponent = ({ index }) => {
//   switch (index) {
//     case 0:
//       return <Display />;
//     case 1:
//       return <Priority />;
//     case 2:
//       return <Status />;
//     case 3:
//       return <Users />;
//     default:
//       return null;
//   }
// }

// function App() {
//   const [isSelected, setIsSelected] = useState(0);

//   return (
//     <div className="app-container">
//       <Navbar buttons={buttons} isSelected={isSelected} setIsSelected={setIsSelected} />
//       <RenderComponent index={isSelected} />
//     </div>
//   );
// }

// export default App;


// // //BEST CODE
// import React, { useState } from 'react';
// import Priority from './Priority';
// import Display from './Display';
// import Status from './Status';
// import Users from './Users';
// // import Navbar from './Navbar';
// import Navbar1 from './NavBar1';
// import "./App.css";
// import PressButton from './PressButton';

// const buttons = [
//   "Priority", "Status", "User", "Title"
// ];

// function App() {
//   const [selectedComponent, setSelectedComponent] = useState(<Display />);

//   const handleButtonClick = ({index}) => {
//     switch (index) {
//       case 0:
//         setSelectedComponent(<Priority />);
//         break;
//       case 1:
//         setSelectedComponent(<Status />);
//         break;
//       case 2:
//         setSelectedComponent(<Users />);
//         break;
//       default:
//         setSelectedComponent(null);
//     }
//   };

//   return (
//     <div className="app-container">
//       {/* <Navbar buttons={buttons} onButtonClick={handleButtonClick} />
//       {selectedComponent} */}
//       {/* <Navbar1 buttons={buttons} onButtonClick={handleButtonClick} />
//       {selectedComponent}  */}
//       <PressButton />
//     </div>
//   );
// }

// export default App;


import React, { useState } from 'react';
import PressButton from './PressButton';



function App() {
  return (
    <div className="app-container">
      <PressButton />
    </div>
  );
}

export default App;
