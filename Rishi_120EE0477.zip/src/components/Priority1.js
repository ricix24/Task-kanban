import React from "react";
import notes from "../notes";
import "./Priority1.css"; // Import your CSS file for styling
import logo from "./logo.png";
import logo1 from "./logo1.jpg";

function Ticket({ ticket }) {
  return (
    <div className="ticket">
      <div className="note">
        <h3 className="heading"><div> {ticket.id}</div>  <div className="profileicons">
            <img className="logo" src={logo}/> 
        </div></h3>
        <p>{ticket.title}</p>
        <h3 className="heading1">
        <div><img className="logo1" src={logo1}/> </div>
        <div> {ticket.tag}</div>  
        </h3>
      </div>
    </div>
  );
}

function Priority() {
  const priorityColumns = [];

  const priorityLevels = [
    { level: 4, name: "Urgent" },
    { level: 3, name: "High" },
    { level: 2, name: "Medium" },
    { level: 1, name: "Low" },
    { level: 0, name: "No priority" },
  ];

  priorityLevels.forEach(priority => {
    const ticketsWithPriority = notes[0].tickets.filter(
      ticket => ticket.priority === priority.level
    );

    if (ticketsWithPriority.length > 0) {
      const column = (
        <div key={priority.level} className="priority-column">
          <h2 className="priority-title">{priority.name}</h2>
          <div className="ticket-list">
            {ticketsWithPriority.map(ticket => (
              <Ticket key={ticket.id} ticket={ticket} />
            ))}
          </div>
        </div>
      );

      priorityColumns.push(column);
    }
  });

  return (
    <div className="container">
      <h1 className="prio">Tickets by Priority</h1>
      <div className="priority-columns">
        {priorityColumns}
      </div>
    </div>
  );
}

export default Priority;
